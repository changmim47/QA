import os

# 1. 폴더 생성
os.makedirs("my-qa-app", exist_ok=True)

# 2. qa_web_app.py 작성
with open("my-qa-app/qa_web_app.py", "w", encoding="utf-8") as f:
    f.write('''import streamlit as st
import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

st.set_page_config(page_title="게시판 QA 자동 평가기", page_icon="📝")
st.title("📋 게시판 QA 자동 평가기")

st.markdown(\"\"\"
이 웹앱은 고객 질문과 상담사 답변을 기반으로 GPT 모델을 활용해 QA 평가를 자동으로 수행합니다.
\"\"\")

customer = st.text_area("고객 질문 입력", height=120)
agent = st.text_area("상담사 답변 입력", height=150)

if st.button("🧠 QA 평가하기"):
    if not customer or not agent:
        st.warning("고객 질문과 상담사 답변을 모두 입력해주세요.")
    else:
        with st.spinner("GPT가 평가 중입니다..."):
            prompt = f\"\"\"
고객 질문: {customer}
상담사 답변: {agent}

다음 기준에 따라 각 항목별 점수(10점 만점)와 간단한 피드백을 작성해주세요:
1. 문제 파악
2. 응답 정확도
3. 공감 표현
4. 문장 구성
5. 해결책 제시
6. 유사 문의 예방
7. 마무리 및 어조
8. 톤앤매너
9. 템플릿 활용
10. 전반적 인상

총점도 함께 알려주세요.
\"\"\"

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.4,
                max_tokens=600
            )
            result = response.choices[0].message.content.strip()

        st.markdown("### 📝 평가 결과")
        st.write(result)
        with st.expander("📋 결과 복사하기"):
            st.code(result, language="markdown")
''')

# 3. .env 템플릿 생성
with open("my-qa-app/.env", "w") as f:
    f.write("OPENAI_API_KEY=sk-여기에-당신의-API키를-입력하세요\n")

# 4. requirements.txt 생성
with open("my-qa-app/requirements.txt", "w") as f:
    f.write("streamlit\nopenai\npython-dotenv\n")

print("✅ 'my-qa-app' 폴더가 생성되었습니다! VS Code에서 바로 실행 가능합니다.")
