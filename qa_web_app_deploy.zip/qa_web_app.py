import streamlit as st
from openai import OpenAI
import os
import pandas as pd
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

st.set_page_config(page_title="게시판 QA 평가기", page_icon="📝")
st.title("📋 게시판 QA 자동 평가기")

st.markdown("""이 웹앱은 고객 질문과 상담사 답변을 기반으로 GPT 모델을 활용해 QA 평가를 자동으로 수행합니다.""")

st.write("📂 CSV 파일을 업로드해 최대 10건까지 평가할 수 있습니다.")

uploaded_file = st.file_uploader("CSV 파일 업로드", type=["csv"])
if uploaded_file and st.button("🧠 평가 시작"):
    df = pd.read_csv(uploaded_file).head(10)
    results = []
    with st.spinner("GPT 평가 진행 중..."):
        for i, row in df.iterrows():
            prompt = f"""너는 고객센터 QA 평가 전문가야.
고객 질문: {row['고객질문']}
상담사 답변: {row['상담사답변']}

[평가 항목]
1. 문제 파악
2. 응답 정확도
3. 공감 표현
4. 해결책 제시
5. 전반적 인상

**마크다운 테이블 형식으로 출력해줘.**
"""
            try:
                response = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.4,
                    max_tokens=800,
                    timeout=60
                )
                results.append(response.choices[0].message.content.strip())
            except Exception as e:
                results.append(f"에러: {e}")

    df["GPT평가결과"] = results
    st.success("✅ 평가 완료!")
    st.download_button("📥 결과 다운로드", df.to_csv(index=False).encode("utf-8-sig"), "qa_results.csv", "text/csv")